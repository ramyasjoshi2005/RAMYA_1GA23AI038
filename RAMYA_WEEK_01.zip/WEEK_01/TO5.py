from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
import matplotlib.pyplot as plt

# Create 3-qubit circuit
qc = QuantumCircuit(3, 3)

# Create superposition
qc.h(0)
qc.h(1)
qc.h(2)

# Measure qubits
qc.measure([0, 1, 2], [0, 1, 2])

print("Quantum Circuit:")
print(qc.draw())


# ----------------------------
# Ideal Simulator
# ----------------------------

ideal_simulator = AerSimulator()

ideal_job = ideal_simulator.run(
    qc,
    shots=1024
)

ideal_result = ideal_job.result()

ideal_counts = ideal_result.get_counts()

print("\nIdeal Simulator:")
print(ideal_counts)


# ----------------------------
# Noise Simulator
# ----------------------------

# Create simulator with default noise model
noise_simulator = AerSimulator(
    method="density_matrix"
)

noise_job = noise_simulator.run(
    qc,
    shots=1024
)

noise_result = noise_job.result()

noise_counts = noise_result.get_counts()

print("\nNoise Simulator:")
print(noise_counts)


# ----------------------------
# Compare Results
# ----------------------------

plot_histogram(
    [ideal_counts, noise_counts],
    legend=[
        "Ideal Simulator",
        "Noise Simulator"
    ]
)

plt.show()