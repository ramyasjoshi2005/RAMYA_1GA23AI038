# Install Qiskit (Run only in Google Colab or Jupyter)
# !pip install qiskit qiskit-aer matplotlib

# Import required libraries
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
import matplotlib.pyplot as plt

# Create a quantum circuit with 3 qubits and 3 classical bits
qc = QuantumCircuit(3, 3)

# Apply Hadamard gate to all three qubits
qc.h([0, 1, 2])

# Measure all qubits
qc.measure([0, 1, 2], [0, 1, 2])

# Display the circuit
print("Quantum Circuit:")
print(qc.draw())

# Create the simulator
simulator = AerSimulator()

# Execute the circuit with 8192 shots
job = simulator.run(qc, shots=8192)

# Get the result
result = job.result()

# Get the measurement counts
counts = result.get_counts()

# Print the measurement counts
print("\nMeasurement Counts:")
print(counts)

# Calculate and print probabilities
print("\nObserved Probabilities:")
for state in sorted(counts):
    probability = counts[state] / 8192
    print(f"{state}: {probability:.4f}")

# Expected probability
print("\nExpected Probability for each state = 1/8 =", 1/8)

# Plot histogram
plot_histogram(counts)