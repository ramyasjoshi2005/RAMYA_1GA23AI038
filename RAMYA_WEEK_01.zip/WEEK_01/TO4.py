# Install (Run only in Google Colab/Jupyter)
# !pip install qiskit qiskit-aer matplotlib

from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
import random
import matplotlib.pyplot as plt

# Number of random bits to generate
N = 1000

# -----------------------------
# Quantum Random Number Generator
# -----------------------------
simulator = AerSimulator()

quantum_bits = []

for _ in range(N):
    qc = QuantumCircuit(1, 1)

    # Put qubit into superposition
    qc.h(0)

    # Measure the qubit
    qc.measure(0, 0)

    # Execute one shot
    job = simulator.run(qc, shots=1)
    result = job.result()
    counts = result.get_counts()

    # Store generated bit
    bit = list(counts.keys())[0]
    quantum_bits.append(int(bit))

# Count 0s and 1s
q0 = quantum_bits.count(0)
q1 = quantum_bits.count(1)

# -----------------------------
# Python Pseudo-Random Generator
# -----------------------------
python_bits = [random.randint(0, 1) for _ in range(N)]

p0 = python_bits.count(0)
p1 = python_bits.count(1)

# -----------------------------
# Print Results
# -----------------------------
print("Quantum Random Generator")
print("0s:", q0)
print("1s:", q1)

print("\nPython Pseudo-Random Generator")
print("0s:", p0)
print("1s:", p1)

# -----------------------------
# Plot Comparison
# -----------------------------
labels = ['0', '1']
quantum_counts = [q0, q1]
python_counts = [p0, p1]

x = range(len(labels))
width = 0.35

plt.figure(figsize=(7,5))
plt.bar([i - width/2 for i in x], quantum_counts, width,
        label='Quantum RNG')
plt.bar([i + width/2 for i in x], python_counts, width,
        label='Python RNG')

plt.xticks(x, labels)
plt.xlabel("Generated Bit")
plt.ylabel("Frequency")
plt.title("Quantum RNG vs Python Pseudo-Random Generator")
plt.legend()
plt.show()