from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

# Create a single-qubit circuit
qc = QuantumCircuit(1)

# Apply H then Z
qc.h(0)
qc.z(0)

# Get the statevector
state = Statevector.from_instruction(qc)

print("Statevector of |-> state:")
print(state)

# Draw the circuit
print("\nQuantum Circuit:")
print(qc.draw())