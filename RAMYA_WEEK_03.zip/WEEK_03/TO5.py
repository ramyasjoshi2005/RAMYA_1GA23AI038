from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

# Circuit 1: HZH
qc1 = QuantumCircuit(1)
qc1.h(0)
qc1.z(0)
qc1.h(0)

# Circuit 2: X
qc2 = QuantumCircuit(1)
qc2.x(0)

# Obtain statevectors
state1 = Statevector.from_instruction(qc1)
state2 = Statevector.from_instruction(qc2)

print("Statevector of HZH:")
print(state1)

print("\nStatevector of X:")
print(state2)

print("\nAre HZH and X equivalent?", state1 == state2)

print("\nCircuit HZH:")
print(qc1.draw())

print("\nCircuit X:")
print(qc2.draw())