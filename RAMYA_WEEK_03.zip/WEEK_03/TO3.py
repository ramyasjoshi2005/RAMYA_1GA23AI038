import random
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

# Available single-qubit gates
gate_list = ['x', 'y', 'z', 'h']

# Create a single-qubit circuit
qc = QuantumCircuit(1)

# Apply 5 random gates
chosen_gates = []
for _ in range(5):
    gate = random.choice(gate_list)
    chosen_gates.append(gate.upper())
    getattr(qc, gate)(0)

# Simulate the circuit
final_state = Statevector.from_instruction(qc)

# Print results
print("Random Gate Sequence:", " -> ".join(chosen_gates))
print("\nFinal Statevector:")
print(final_state)

print("\nQuantum Circuit:")
print(qc.draw())