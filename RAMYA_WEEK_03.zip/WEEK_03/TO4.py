from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

# Create a single-qubit circuit
qc = QuantumCircuit(1)

# Apply Hadamard gate (Quantum Coin Flip)
qc.h(0)

# Get the statevector
state = Statevector.from_instruction(qc)

# Calculate probabilities
probabilities = state.probabilities()

print("Statevector:")
print(state)

print("\nProbability of Heads (|0>):", probabilities[0])
print("Probability of Tails (|1>):", probabilities[1])

print("\nQuantum Circuit:")
print(qc.draw())