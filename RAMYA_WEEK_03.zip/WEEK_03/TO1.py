from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

gates = {
    "X": "x",
    "Y": "y",
    "Z": "z"
}

for gate_name, gate_method in gates.items():
    qc = QuantumCircuit(1)
    getattr(qc, gate_method)(0)
    state = Statevector.from_instruction(qc)

    print(f"{gate_name} Gate:")
    print(state)
    print()