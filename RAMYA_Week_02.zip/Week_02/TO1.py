from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_bloch_multivector, plot_state_city
import matplotlib.pyplot as plt

# Create a 1-qubit circuit
qc = QuantumCircuit(1)

# Initial state is |0>
print("Initial circuit:")
print(qc)

# Apply X gate: |0> -> |1>
qc.x(0)

print("\nCircuit after X gate:")
print(qc)

# Get the resulting statevector
state = Statevector.from_instruction(qc)

# Print statevector
print("\nResulting statevector:")
print(state)

# Visualise statevector
plot_state_city(state)
plt.show()

# Optional: Bloch sphere visualisation
plot_bloch_multivector(state)
plt.show()