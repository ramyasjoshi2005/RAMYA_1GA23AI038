from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_bloch_multivector
import numpy as np
import matplotlib.pyplot as plt

# Create |+> state
qc = QuantumCircuit(1)
qc.h(0)

# Ideal state
ideal_state = Statevector.from_instruction(qc)

# Add random phase error
phi = np.random.uniform(-0.2, 0.2)

print(f"Random phase error: {phi:.4f} radians")

qc.rz(phi, 0)

# Noisy state
noisy_state = Statevector.from_instruction(qc)

print("\nIdeal statevector:")
print(ideal_state)

print("\nNoisy statevector:")
print(noisy_state)

# Plot ideal state
plot_bloch_multivector(ideal_state)
plt.title("Ideal |+> state")
plt.show()

# Plot noisy state
plot_bloch_multivector(noisy_state)
plt.title(f"Noisy state (phase error = {phi:.4f} rad)")
plt.show()