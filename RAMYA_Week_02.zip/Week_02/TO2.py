from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_bloch_multivector
import matplotlib.pyplot as plt

# Create a single-qubit circuit
qc = QuantumCircuit(1)

# Apply Hadamard gate: |0> -> |+>
qc.h(0)

# Apply Phase (S) gate
qc.s(0)

# Display circuit
print(qc)

# Calculate final statevector
state = Statevector.from_instruction(qc)

# Print statevector
print("\nFinal statevector:")
print(state)

# Plot on Bloch sphere
plot_bloch_multivector(state)
plt.show()