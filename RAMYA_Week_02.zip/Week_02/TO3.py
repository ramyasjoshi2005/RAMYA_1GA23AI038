from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
import numpy as np

# Create a 2-qubit circuit
qc = QuantumCircuit(2)

# Apply Hadamard to both qubits
# |00> -> (|0>+|1>)/sqrt(2) ⊗ (|0>+|1>)/sqrt(2)
qc.h(0)
qc.h(1)

# Obtain the statevector
state = Statevector.from_instruction(qc)

print("Circuit:")
print(qc)

print("\nStatevector:")
print(state)

# Extract amplitudes
amplitudes = state.data

print("\nAmplitudes:")
for basis, amp in zip(["|00>", "|01>", "|10>", "|11>"], amplitudes):
    print(f"{basis}: {amp}")

# Verify normalization
probability_sum = np.sum(np.abs(amplitudes)**2)

print("\nSum of squared amplitudes:")
print(probability_sum)

if np.isclose(probability_sum, 1):
    print("Statevector is normalized ✓")
else:
    print("Statevector is not normalized ✗")