import numpy as np
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_bloch_multivector
import matplotlib.pyplot as plt


def create_qubit_state(theta, phi):
    """
    Construct a qubit state from Bloch sphere angles theta and phi.

    theta: polar angle (radians)
    phi: azimuthal angle (radians)
    """

    # Construct statevector manually
    alpha = np.cos(theta / 2)
    beta = np.exp(1j * phi) * np.sin(theta / 2)

    manual_state = np.array([alpha, beta])

    # Create Qiskit statevector
    state = Statevector(manual_state)

    print("Input angles:")
    print(f"theta = {theta:.4f} rad")
    print(f"phi   = {phi:.4f} rad")

    print("\nConstructed statevector:")
    print(state)

    # Manual Bloch vector calculation
    x = np.sin(theta) * np.cos(phi)
    y = np.sin(theta) * np.sin(phi)
    z = np.cos(theta)

    manual_bloch = np.array([x, y, z])

    print("\nManual Bloch vector:")
    print(manual_bloch)

    # Validate normalization
    amplitude_sum = np.sum(np.abs(manual_state)**2)

    print("\nNormalization check:")
    print(f"|alpha|² + |beta|² = {amplitude_sum}")

    if np.isclose(amplitude_sum, 1):
        print("State is normalized ✓")
    else:
        print("State is not normalized ✗")

    # Plot Bloch sphere
    plot_bloch_multivector(state)
    plt.title(
        f"Qubit state: θ={theta:.2f}, φ={phi:.2f}"
    )
    plt.show()

    return state, manual_bloch


# Example: theta=60 degrees, phi=45 degrees
theta = np.deg2rad(60)
phi = np.deg2rad(45)

state, bloch = create_qubit_state(theta, phi)